export const colorOptions = [
  { value: 'bg-red-500/20 text-red-500', label: 'Red' },
  { value: 'bg-blue-500/20 text-blue-500', label: 'Blue' },
  { value: 'bg-green-500/20 text-green-500', label: 'Green' },
  { value: 'bg-yellow-500/20 text-yellow-500', label: 'Yellow' },
  { value: 'bg-purple-600/20 text-purple-600', label: 'Purple' },
  { value: 'bg-gray-600/20 text-gray-600', label: 'Gray' },
  { value: 'bg-violet-500/20 text-violet-500', label: 'Violet' },
];